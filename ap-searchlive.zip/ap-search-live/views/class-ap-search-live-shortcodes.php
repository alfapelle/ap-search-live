<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

if ( !function_exists( 'ap_search_live' ) ) {
	
	function search_live( $atts = array() ) {
		return AP_Search_Live_Shortcodes::ap_search_live( $atts );
	}
}

class AP_Search_Live_Shortcodes {

	public static function init() {
		add_shortcode( 'ap_search_live', array( __CLASS__, 'ap_search_live' ) );
	}

	public static function load_resources() {
		$options = AP_Search_Live::get_options();
		wp_enqueue_script( 'typewatch' );
		wp_enqueue_script( 'ap-search-live' );
		wp_enqueue_style( 'ap-search-live' );
	}

	public static function ap_search_live( $atts = array(), $content = '' ) {
		
		self::load_resources();
		$atts = shortcode_atts(
			array(
				'order'               => null,
				'custom_order'	      => null,
				'choosen_cf'          => null,
				'category_order'	  => array()

			),
			$atts
		);

		$url_params = array();
		
		$params = array();
		
		$floating = 'floating' ;

		$params['inhibit_enter'] = true;

		$params['auto_adjust'] = true;

		$params['delay'] = AP_Search_Live::DEFAULT_DELAY;
		
		$params['characters'] = AP_Search_Live::DEFAULT_CHARACTERS;
		
		$params['placeholder'] = apply_filters( 'ap_search_live_placeholder', $params['placeholder'] );
		
		$params['no_results']  = apply_filters( 'ap_search_live_no_results', $params['no_results'] );

		$output = '';

		$ap_search_live = true;

		$n          = rand();
		$search_id  = 'ap-search-live-' . $n;
		$form_id    = 'ap-search-live-form-' . $n;
		$field_id   = 'apsearch-live-field-' . $n;
		$results_id = 'ap-search-live-results-' .$n;

		$output .= sprintf('<div id="%s" class="ap-search-live %s">', esc_attr( $search_id ), esc_attr($floating));

		$output .= '<div class="ap-search-live-form">';
		
		$output .= sprintf( '<form role="search" id="%s" class="ap-search-live-form" action="%s" method="get">', esc_attr( $form_id ), esc_url( home_url( '/' ) ) );
		
		$output .= '<div>';
		
		$output .= '<span class="screen-reader-text"></span>';
		
		$output .= sprintf('<input id="%s" name="s" type="text" class="ap-search-live-field" placeholder="Search" autocomplete="off" value="%s" />', esc_attr( $field_id ), get_search_query() );

		$output .= sprintf( '<input type="hidden" name="limit" value="%d"/>', intval( AP_Search_Live_Service::DEFAULT_LIMIT) );
		
		$output .= '<input type="hidden" name="ixsl" value="1"/>';

		$output .= '</div>';
		$output .= '</form>';
		$output .= '</div>'; // .ap-search-live-form

		$output .= sprintf( '<div id="%s" class="ap-search-live-results">', $results_id );
		$output .= '</div>'; // .ap-search-live-results

		$output .= '</div>'; // .ap-search-live

		
		$js_args = array();
		$js_args[] = 'no_results:" no match found "';
		$js_args[] = 'dynamic_focus:false';
		
		$js_args[] = 'thumbnails:true';
		
		$js_args[] = 'show_description:true';
		
		$js_args = '{' . implode( ',', $js_args ) . '}';

		$post_target_url = add_query_arg( $url_params , admin_url( 'admin-ajax.php' ) ); 

		
		$output .= '<script type="text/javascript">';
		
		$output .= 'if ( typeof jQuery !== "undefined" ) {';
		
		$output .= 'jQuery(document).ready(function(){';
		
		$output .= sprintf(
			'jQuery("#%s").typeWatch( {
				callback: function (value) { ixsl.searchLive(\'%s\', \'%s\', \'%s\', \'%s\', value, %s); },
				wait: %d,
				highlight: true,
				captureLength: %d
			} );',
			esc_attr( $field_id ), // jQuery selector for the input field
			esc_attr( $field_id ), // jQuery selector for the input field passed to searchLive()
			esc_attr( $search_id ), // container selector
			esc_attr( $search_id . ' div.ap-search-live-results' ), // results container selector
			$post_target_url,
			$js_args,
			$params['delay'],
			$params['characters']
		);

		if ( $params['inhibit_enter'] ) {
			$output .= sprintf( 'ixsl.inhibitEnter("%s");', $field_id );
		}
		
		if ( $params['auto_adjust'] ) {
			$output .= sprintf( 'ixsl.autoAdjust("%s","%s");', $field_id, $results_id );
		}

		$output .= '});'; // ready

		$output .= '}'; // if
		
		$output .= '</script>';

		return $output;
	}


}
AP_Search_Live_Shortcodes::init();
