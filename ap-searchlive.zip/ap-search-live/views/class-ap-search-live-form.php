<?php

if ( !defined( 'ABSPATH' ) ) exit;

class AP_Search_Live_Form {

	public static function init() {
		$options = AP_Search_Live::get_options();
		
	}

}
AP_Search_Live_Form::init();
