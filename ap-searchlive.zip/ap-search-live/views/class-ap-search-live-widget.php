<?php

if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class AP_Search_Live_Widget extends WP_Widget {

	static $the_name = '';

	static $cache_id = 'ap_search_live_widget';
	static $cache_flag = 'widget';
	static $defaults = array();

	static function init() {
		add_action( 'widgets_init', array( __CLASS__, 'widgets_init' ) );
		self::$the_name ='AP Search Live';
	}

	static function widgets_init() {
		register_widget( 'AP_Search_Live_Widget' );

	}

	function __construct() {
		parent::__construct(
			self::$cache_id,
			self::$the_name,
			array(
				'description' => __( 'The AP Search Live Widget', 'ap-search-live' )
			)

		);
		add_action('wp_ajax_update_field_order', array( __CLASS__, 'update_field_order' ));

	}

	static function cache_delete() {
		wp_cache_delete( self::$cache_id, self::$cache_flag);
	}

	function widget( $args, $instance ) {
		
		AP_Search_Live_Shortcodes::load_resources();

		$cache = wp_cache_get( self::$cache_id, self::$cache_flag );
		if ( ! is_array( $cache ) ) {
			$cache = array();
		}
		if ( isset( $cache[$args['widget_id']] ) ) {
			echo $cache[$args['widget_id']];
			return;
		}

		extract( $args );

		$title = apply_filters( 'widget_title', $instance['title'] );

		$output = '';

		$output .= $before_widget;

		if ( !empty( $title ) ) {
			$output .= $before_title . $title . $after_title;
		}
		$instance['title'] = $instance['query_title'];

		$output .= AP_Search_Live_Shortcodes::ap_search_live( $instance );
		
		$output .= $after_widget;

		echo $output;

		$cache[$args['widget_id']] = $output;
		wp_cache_set( self::$cache_id, $cache, self::$cache_flag );

	}

	function update( $new_instance, $old_instance ) {

		global $wpdb;

		$settings = $old_instance;
				
		$settings['order']    = !empty( $new_instance['order'] ) ? $new_instance['order'] : ' ';
		
		$settings['custom_order']= !empty( $new_instance['custom_order'] ) ? $new_instance['custom_order'] : ' ';
		
		$settings['choosen_cf'] = !empty( $new_instance['choosen_cf'] ) ? $new_instance['choosen_cf'] : ' ';
		
		$settings['category_order'] = self::get_our_categories();
		
		$this->cache_delete();
		
		return $settings;
	}

	function form( $instance ) {

		self::insert_term_order();

		extract( self::$defaults );

		echo '<h5>Order Results</h5>';
		
		$custom_order = isset( $instance['custom_order'] ) ? $instance['custom_order'] : ' ';
		echo '<p>';

		echo '<label>';
		printf( '<input type="radio" name="%s" value="CAT" %s />', $this->get_field_name( 'custom_order' ),  $custom_order == 'CAT' ? ' checked="checked" ' : '' );
		echo ' ';
		echo 'Order by category';

		echo '<div>';
		
		$category_order = self::get_our_categories();
		
		$csort = array();
		foreach ($category_order as $key => $row)
		{
		    $csort[$key] = $row['term_order'];
		}
		array_multisort($csort, SORT_ASC, $category_order);

		echo '<ul class="APsortable APbox">';

		foreach($category_order as $cats){
			
				printf('<li id="%s">',$cats['term_id']);
				printf( '<span>%s</span>',  $cats['name']);
				echo '</li>';
		}
		echo '</ul>';
			
		echo '</div>';

		echo '</label>';
		
		?>
		<script>
		
		jQuery(document).ready(function(){
			
			jQuery( ".APsortable" ).sortable({
	   			
               	axis: "y",
               		
               	stop: function(event, ui){
               		var order = jQuery(this).sortable('toArray');            		
               		jQuery.ajax({
            			url : ajaxurl,
            			type : 'post',
            		
            			data : {
               			    action : 'update_field_order',
                			order : order
            			}
               		});
               		
						
               		 }});//
	        jQuery(".APsortable").disableSelection();
		

			});
			
  		</script>

  		<style>
  		
  		.APbox{margin-left:25px; margin-bottom: 20px;}
  		.APsortable li { margin:0 20px 15px 0px;   }
  		.APsortable li span { padding:3px; background-color: #eee; border-radius: 5px; cursor: pointer; }
  		</style>
  		
  		<?php

		echo '<label>';
		printf( '<input type="radio" name="%s" value="CF" %s />', $this->get_field_name( 'custom_order' ),  $custom_order == 'CF' ? ' checked="checked" ' : ''  );
		echo ' ';
		echo 'Order by custom field';
		echo '<div class="APbox">';
		
		$choosen_cf = isset( $instance['choosen_cf'] ) ? $instance['choosen_cf'] : ' ';

		echo '<p>';
		echo sprintf( '<label title="%s">', sprintf('Order the posts of a choosen custom field' ) );
		echo 'Choose the custom field...';
		echo ' ';
		printf( '<select id="%s" name="%s">', $this->get_field_id( 'choosen_cf' ), $this->get_field_name( 'choosen_cf'));
		
		$custom_fields = self::get_meta_key();

		foreach( $custom_fields as $cf ) {
			printf( '<option value="%s" %s>%s</option>', $cf, $choosen_cf == $cf ? ' selected="selected" ' : '',$cf);
		}
		echo '</select>';
		echo '</label>';
		echo '</p>';


		$order = isset( $instance['order'] ) ? $instance['order'] : ' ';
		echo '<p>';
		echo '<label>';
		printf( '<input type="radio" name="%s" value="ASC" %s />', $this->get_field_name( 'order' ), $order == 'ASC' ? ' checked="checked" ' : '' );
		echo ' ';
		echo 'Ascending';
		echo '</label>';
		echo ' ';
		echo '<label>';
		printf( '<input type="radio" name="%s" value="DESC" %s />', $this->get_field_name( 'order' ), $order == 'DESC' ? ' checked="checked" ' : '' );
		echo ' ';
		echo 'Descending';
		echo '</label>';
		echo '</p>';
		
		echo '</div>';
		echo '</label>';
		
		echo '</p>';

		
	}

	function get_meta_key(){
		global $wpdb;
		
		$keys = $wpdb->get_col("SELECT DISTINCT (meta_key) FROM $wpdb->postmeta WHERE $wpdb->postmeta.meta_key NOT LIKE '%/_%' ESCAPE '/' ");
		return $keys;
	}

	function get_our_categories(){
		global $wpdb;
		$cats=array();
		$cats = $wpdb->get_results('SELECT (name),(term_id),(term_order) FROM wp_terms',ARRAY_A);
		return $cats;
	}


	public function update_field_order() {
    global $wpdb;
  
    $order = $_POST['order'];
    foreach ($order as $position => $item) {
    	$wpdb->query("UPDATE $wpdb->terms SET $wpdb->terms.term_order= $position+1 WHERE $wpdb->terms.term_id = $item "  );
	    }
    	wp_die();
	}

	function insert_term_order(){
		global $wpdb;
		$wpdb->query("ALTER TABLE $wpdb->terms ADD term_order INT(4) NOT NULL DEFAULT 1");	

	}
	
}

AP_Search_Live_Widget::init();
