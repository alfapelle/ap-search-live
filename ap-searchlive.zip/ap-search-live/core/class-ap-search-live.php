<?php


if ( !defined( 'ABSPATH' ) ) {
	exit;
}

class AP_Search_Live {

	const OPTIONS                   = 'ap-search-live';
	const DB_PREFIX                 = 'ap_search_live_';
	const DESCRIPTION_LENGTH                   = 'description-length';
	const DESCRIPTION_LENGTH_DEFAULT           = 15;	
	const ENABLE_CSS_DEFAULT        = true;
	const DEFAULT_DELAY             = 500;
	const DEFAULT_CHARACTERS        = 4;
	
	public static function init() {
		require_once AP_SEARCH_LIVE_CORE_LIB . '/class-ap-search-live-service.php';
		require_once AP_SEARCH_LIVE_VIEWS_LIB . '/class-ap-search-live-shortcodes.php';
		require_once AP_SEARCH_LIVE_VIEWS_LIB . '/class-ap-search-live-widget.php';
		require_once AP_SEARCH_LIVE_VIEWS_LIB . '/class-ap-search-live-thumbnail.php';
		require_once AP_SEARCH_LIVE_VIEWS_LIB . '/class-ap-search-live-form.php';
		
	}

	public static function get_options() {
		$data = get_option( self::OPTIONS, null );
		if ( $data === null ) {
			if ( add_option( self::OPTIONS, array(), '', 'no' ) ) {
				$data = get_option( self::OPTIONS, null );
			}
		}
		return $data;
	}
	
}
AP_Search_Live::init();