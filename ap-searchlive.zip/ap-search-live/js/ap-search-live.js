var ixsl = {
	doPost : true, 
	blinkerTimeouts : [],
	blinkerTimeout : 5000
};

(function($) {

ixsl.inhibitEnter = function( fieldId ) {
	$("#"+fieldId).keydown(function(e){
		if ( e.keyCode == 13 ) { // enter
			e.preventDefault();
			return false;
		}
	});
};

ixsl.autoAdjust = function( fieldId, resultsId ) {
	var $field = $('#'+fieldId),
		$results = $('#'+resultsId);
	$results.on('adjustWidth',function(e){
		e.stopPropagation();
		// Field width minus own border.
		var w = $field.outerWidth() - ( $results.outerWidth() - $results.innerWidth() );
		$results.width(w);
	});
	$(window).on('resize',function(e){
		$results.trigger('adjustWidth');
	});
};

ixsl.searchLive = function( fieldId, containerId, resultsId, url, query, args ) {

	if (!ixsl.doPost) {
		return;
	}

	if ( typeof args === "undefined" ) {
		args = {};
	}

	var $results = $( "#"+resultsId ),
		$blinker = $( "#"+fieldId ),
		blinkerTimeout = ixsl.blinkerTimeout;

	if ( typeof args.blinkerTimeout !== "undefined" ) {
		blinkerTimeout = args.blinkerTimeout;
	}
	query = $.trim(query);
	if ( query != "" ) {
		$blinker.addClass('blinker');
		if ( blinkerTimeout > 0 ) {
			ixsl.blinkerTimeouts["#"+fieldId] = setTimeout(function(){$blinker.removeClass('blinker');}, blinkerTimeout);
		}
		var params = {
			"action" : "ap_search_live",
			"ap-search-live": 1,
			"ap-search-live-query": query
		};
		if ( typeof args.lang !== "undefined" ) {
			params.lang = args.lang;
		}
		$.post(
			url,
			params,
			function ( data ) {
				var results = '';
				if ( ( data !== null ) && ( data.length > 0 ) ) {
					var result_type = null,
						current_type = null,
						thumbnails = true,
						show_description = false;
					if ( typeof args.thumbnails !== "undefined" ) {
						thumbnails = args.thumbnails;
					}
					if ( typeof args.show_description !== "undefined" ) {
						show_description = args.show_description;
					}
					// Search results table start.
					results += '<table class="search-results">';
					for( var key in data ) {
						var first = '';
						if ( current_type != data[key].type ) {
							current_type = data[key].type;
							first = 'first';
						}
						if ( result_type != data[key].result_type ) {
							result_type = data[key].result_type;
						}

						results += '<tr class="entry ' + data[key].result_type + ' ' + data[key].type + ' ' + first + '">';
						if ( thumbnails ) {
							results += '<td class="result-image">';
							results += '<a href="' + data[key].url + '" title="' + data[key].title + '">';
							if ( typeof data[key].thumbnail !== "undefined" ) {
								var width = '', height = '', alt='';
								if ( typeof data[key].thumbnail_alt !== "undefined" ) {
									alt = ' alt="' + data[key].thumbnail_alt + '" ';
								}
								if ( typeof data[key].thumbnail_width !== "undefined" ) {
									width = ' width="' + data[key].thumbnail_width + '" ';
								}
								if ( typeof data[key].thumbnail_height !== "undefined" ) {
									height = ' height="' + data[key].thumbnail_height + '" ';
								}
								results += '<img class="thumbnail" src="' + data[key].thumbnail + '" ' + alt + width + height + '/>';
							}
							results += '</a>';
							results += '</td>';
						}

						results += '<td class="result-info">';
						results += '<a href="' + data[key].url + '" title="' + data[key].title + '">';
						results += '<span class="title">' + data[key].title + '</span>';
						if ( show_description ) {
							if ( typeof data[key].description !== "undefined" ) {
								results += '<span class="description">' + data[key].description + '</span>';
							}
						}
						results += '</a>';
						results += '</td>';
						results += '</tr>';
					}
					results += '</table>';
					
					};

				} else {
					if ( typeof args.no_results !== "undefined" ) {
						if ( args.no_results.length > 0 ) {
							results += '<div class="no-results">';
							results += args.no_results;
							results += '</div>';
						}
					}
				}
				$results.show().html( results );
				ixsl.clickable( resultsId );
				$results.trigger('adjustWidth');
				$blinker.removeClass('blinker');
				if ( blinkerTimeout > 0 ) {
					clearTimeout(ixsl.blinkerTimeouts["#"+fieldId]);
				}
			},
			"json"
		);
	} else {
		// Hide and empty the results for an empty query.
		// If we don't get here (minimum characters not input), [1] will empty it.
		$results.hide().html('');
	}
};

ixsl.clickable = function( resultsId ) {
	$('#' + resultsId + ' table.search-results tr').click(function(){
		var url = $(this).find('a').attr('href');
		if ( url ) {
			window.location = url;
		}
	});
	$('#' + resultsId + ' table.search-results tr').css('cursor','pointer');
};

})(jQuery);
